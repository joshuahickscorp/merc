"""Independent clean-room parametric construction for NOCTURNE/ONE.

Run:
  Blender --background --factory-startup --python 3d/build_candidate.py
"""
from pathlib import Path
import bpy, bmesh, math
from mathutils import Vector

ROOT = Path(__file__).resolve().parents[1]
ASSETS = ROOT / "public" / "assets"
ASSETS.mkdir(parents=True, exist_ok=True)
bpy.ops.wm.read_factory_settings(use_empty=True)
bpy.context.scene.unit_settings.system = "METRIC"
bpy.context.scene.unit_settings.scale_length = .001

def mat(name, color, metallic=0, rough=.45, transmission=0, emission=None):
    m=bpy.data.materials.new(name); m.use_nodes=True
    p=m.node_tree.nodes.get("Principled BSDF")
    p.inputs["Base Color"].default_value=(*color,1); p.inputs["Metallic"].default_value=metallic
    p.inputs["Roughness"].default_value=rough
    if "Transmission Weight" in p.inputs: p.inputs["Transmission Weight"].default_value=transmission
    if emission:
        p.inputs["Emission Color"].default_value=(*emission[0],1); p.inputs["Emission Strength"].default_value=emission[1]
    if transmission: m.surface_render_method="DITHERED"
    return m

shell=mat("MAT_BLACK_ANODIZED_ALUMINUM",(0.006,0.008,0.012),.82,.28)
glass=mat("MAT_FROSTED_TRANSLUCENT_GLASS",(0.18,.27,.34),0,.24,.72)
glow=mat("MAT_WARM_EMISSIVE_CERAMIC",(1,.28,.06),0,.3,0,((1,.24,.035),5))
textile=mat("MAT_GRAPHITE_TENSIONED_TEXTILE",(.018,.022,.03),0,.86)
metal=mat("MAT_MACHINED_ALUMINUM",(.28,.31,.34),.9,.2)
board=mat("MAT_LOGIC_BOARD",(.02,.12,.08),.05,.5)

parts={}
def finish(obj,name,material):
    obj.name=name; obj.data.name=f"{name}_LOD0"; obj.data.materials.append(material)
    bpy.context.view_layer.objects.active=obj; obj.select_set(True)
    if obj.type=="MESH":
        bpy.ops.object.transform_apply(location=False,rotation=False,scale=True)
        bm=bmesh.new(); bm.from_mesh(obj.data)
        boundary=[e for e in bm.edges if e.is_boundary]
        if boundary: bmesh.ops.holes_fill(bm,edges=boundary,sides=0)
        bm.to_mesh(obj.data); bm.free(); obj.data.update()
        for poly in obj.data.polygons: poly.use_smooth=True
        bpy.ops.object.mode_set(mode="EDIT"); bpy.ops.mesh.select_all(action="SELECT")
        bpy.ops.uv.smart_project(angle_limit=1.15192); bpy.ops.mesh.normals_make_consistent(inside=False)
        bpy.ops.object.mode_set(mode="OBJECT")
    obj["semantic_part"]=name; obj["lod_identity"]=name
    parts[name]=obj; return obj
def cube(name,loc,scale,material,bevel=2):
    bpy.ops.mesh.primitive_cube_add(location=loc); o=bpy.context.object; o.scale=scale
    if bevel:
        mod=o.modifiers.new("finite_edge_radius","BEVEL"); mod.width=bevel; mod.segments=3
        bpy.context.view_layer.objects.active=o; bpy.ops.object.modifier_apply(modifier=mod.name)
    return finish(o,name,material)
def uv_sphere(name,loc,scale,material,segments=48,rings=24):
    bpy.ops.mesh.primitive_uv_sphere_add(segments=segments, ring_count=rings, location=loc)
    o=bpy.context.object; o.scale=scale; return finish(o,name,material)
def cylinder(name,loc,radius,depth,material,rotation=(math.pi/2,0,0),vertices=48):
    bpy.ops.mesh.primitive_cylinder_add(vertices=vertices,radius=radius,depth=depth,location=loc,rotation=rotation)
    return finish(bpy.context.object,name,material)

cube("base",(0,0,17),(160,90,17),shell,18)
# Continuous asymmetric arch from authoritative profile, with depth ellipse.
curve=bpy.data.curves.new("outer_shell_arch_path","CURVE"); curve.dimensions="3D"; curve.resolution_u=3
curve.bevel_depth=24; curve.bevel_resolution=5; curve.resolution_u=12
s=curve.splines.new("BEZIER"); pts=[(-112,0,33),(-136,1,112),(-124,3,232),(-75,5,319),(10,3,356),(95,0,298),(136,-2,201),(128,-3,88),(94,-2,33)]
s.bezier_points.add(len(pts)-1)
for bp,co in zip(s.bezier_points,pts): bp.co=co; bp.handle_left_type="AUTO"; bp.handle_right_type="AUTO"
o=bpy.data.objects.new("outer_shell",curve); bpy.context.collection.objects.link(o)
bpy.context.view_layer.objects.active=o; o.select_set(True); bpy.ops.object.convert(target="MESH")
o=bpy.context.object; o.scale.y=1.22; finish(o,"outer_shell",shell)
uv_sphere("glass_core",(-8,-4,178),(61,48,126),glass)
cylinder("eclipse_disk",(-8,39,181),54,8,glow,(math.pi/2,0,0))
uv_sphere("acoustic_membrane",(-8,-48,176),(54,4,111),textile,40,20)
# grille as one clean slotted panel to preserve semantic identity
cube("thermal_grille",(0,87,75),(110,1.2,9),shell,1)
cylinder("rotary_control",(104,-76,41),17,13,metal,(math.pi/2,0,0))
# Bezier cable, then convert for UV topology.
c=bpy.data.curves.new("braided_cable_path","CURVE"); c.dimensions="3D"; c.bevel_depth=3.2; c.bevel_resolution=3; c.resolution_u=10
sp=c.splines.new("BEZIER"); cps=[(58,86,20),(106,121,12),(164,136,7),(220,124,5)]; sp.bezier_points.add(3)
for bp,co in zip(sp.bezier_points,cps): bp.co=co; bp.handle_left_type="AUTO"; bp.handle_right_type="AUTO"
o=bpy.data.objects.new("braided_cable",c); bpy.context.collection.objects.link(o); bpy.context.view_layer.objects.active=o;o.select_set(True);bpy.ops.object.convert(target="MESH");finish(bpy.context.object,"braided_cable",textile)
cube("internal_frame",(-8,3,178),(52,34,118),metal,4)
cube("logic_board",(-8,12,76),(47,2,24),board,1)
cylinder("left_driver",(-76,-8,178),29,18,textile,(math.pi/2,0,0),40)
cylinder("right_driver",(65,-8,178),29,18,textile,(math.pi/2,0,0),40)

offsets={"acoustic_membrane":(0,-82,0),"eclipse_disk":(0,58,0),"glass_core":(0,-46,0),"internal_frame":(0,28,0),"left_driver":(-58,-28,0),"logic_board":(0,76,-18),"outer_shell":(0,0,44),"right_driver":(58,-28,0)}
for name,off in offsets.items():
    o=parts[name]; origin=o.location.copy(); o.keyframe_insert("location",frame=1)
    o.location=origin+Vector(off); o.keyframe_insert("location",frame=120); o.location=origin
    if o.animation_data and o.animation_data.action:
        for fc in o.animation_data.action.fcurves:
            for kp in fc.keyframe_points: kp.interpolation="BEZIER"
bpy.context.scene.frame_start=1; bpy.context.scene.frame_end=120; bpy.context.scene.frame_set(1)

# Collections and metadata make the editable hierarchy explicit.
for o in parts.values(): o.select_set(True)
bpy.context.scene["model"]="NOCTURNE/ONE"; bpy.context.scene["source_authority"]="TEXTUAL_PARAMETRIC_GROUND_TRUTH"
bpy.ops.wm.save_as_mainfile(filepath=str(ROOT/"3d"/"nocturne-one.blend"))

def export(path, low=False):
    bpy.ops.object.select_all(action="DESELECT")
    for o in parts.values(): o.select_set(True)
    bpy.ops.export_scene.gltf(filepath=str(path),export_format="GLB",use_selection=True,export_animations=True,
        export_yup=True,export_apply=False,export_materials="EXPORT")
export(ASSETS/"nocturne-one-hero.glb")
export(ASSETS/"nocturne-one-low.glb",True)
print("Built",len(parts),"semantic parts")
