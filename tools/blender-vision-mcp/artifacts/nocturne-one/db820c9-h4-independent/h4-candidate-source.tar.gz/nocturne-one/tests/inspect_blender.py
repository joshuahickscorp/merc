import bpy,bmesh,sys,json,math
from pathlib import Path
root=Path(__file__).resolve().parents[1]
required={"base","outer_shell","glass_core","eclipse_disk","acoustic_membrane","thermal_grille","rotary_control","braided_cable","internal_frame","logic_board","left_driver","right_driver"}
bpy.ops.wm.open_mainfile(filepath=str(root/"3d"/"nocturne-one.blend"))
objects={o.name:o for o in bpy.context.scene.objects}
assert required <= objects.keys(), required-objects.keys()
assert {"MAT_FROSTED_TRANSLUCENT_GLASS","MAT_WARM_EMISSIVE_CERAMIC"} <= set(bpy.data.materials.keys())
report={"parts":{},"animation_parts":[]}
for name in required:
 o=objects[name]; assert o.type=="MESH"; assert all(v>0 for v in o.scale); assert len(o.data.uv_layers)>0
 assert all(math.isfinite(x) for v in o.data.vertices for x in (*v.co,*v.normal))
 bm=bmesh.new();bm.from_mesh(o.data);bad=sum(not e.is_manifold for e in bm.edges);bm.free()
 assert bad==0,(name,bad);report["parts"][name]={"vertices":len(o.data.vertices),"uv_layers":len(o.data.uv_layers),"non_manifold_edges":bad}
 if o.animation_data and o.animation_data.action: report["animation_parts"].append(name)
assert len(report["animation_parts"])==8
for glb in ["nocturne-one-hero.glb","nocturne-one-low.glb"]:
 bpy.ops.wm.read_factory_settings(use_empty=True);bpy.ops.import_scene.gltf(filepath=str(root/"public"/"assets"/glb))
 names={o.name.split(".")[0] for o in bpy.context.scene.objects if o.type=="MESH"};assert required<=names,(glb,required-names)
 report[glb]={"mesh_count":len(names),"required_names_present":True}
(root/"test-results").mkdir(exist_ok=True);(root/"test-results"/"blender-inspection.json").write_text(json.dumps(report,indent=2))
print(json.dumps(report))
