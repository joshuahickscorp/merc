import {defineConfig} from "vitest/config";
export default defineConfig({root:"src",publicDir:"../public",build:{outDir:"../dist",emptyOutDir:true},server:{proxy:{"/api":"http://127.0.0.1:4173"}},test:{root:"..",include:["nocturne-one/tests/**/*.test.ts"]}});
