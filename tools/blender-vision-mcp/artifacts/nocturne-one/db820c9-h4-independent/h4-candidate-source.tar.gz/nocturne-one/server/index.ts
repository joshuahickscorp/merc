import {app} from "./app.js";const port=Number(process.env.PORT||4173);app.listen(port,"127.0.0.1",()=>console.log(`NOCTURNE/ONE http://127.0.0.1:${port}`));
