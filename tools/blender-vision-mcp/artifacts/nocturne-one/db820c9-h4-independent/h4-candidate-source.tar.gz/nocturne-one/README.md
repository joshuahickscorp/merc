# NOCTURNE/ONE

Clean-room TypeScript, SQLite, and independently generated Blender implementation.

`npm ci && npm run db:migrate && npm run verify && npm start`

Rebuild 3D with `/Applications/Blender.app/Contents/MacOS/Blender --background --factory-startup --python 3d/build_candidate.py`.
